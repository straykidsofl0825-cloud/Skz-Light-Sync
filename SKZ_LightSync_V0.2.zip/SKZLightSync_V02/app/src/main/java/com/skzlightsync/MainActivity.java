package com.skzlightsync;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.graphics.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new LightSyncView(this));
    }
}

class LightSyncView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler handler = new Handler();

    // V0.2: project is stored locally so execution can continue without internet.
    final Project project = Project.demo();
    int screen = 0;
    int selectedSector = 0;
    boolean downloaded = true;
    long localStartElapsed = 0L;
    long clockOffsetMs = 0L;

    final int BG = Color.rgb(5,7,13);
    final int CARD = Color.rgb(12,20,34);
    final int WHITE = Color.WHITE;
    final int MUTED = Color.rgb(155,168,192);
    final int BLUE = Color.rgb(38,155,255);
    final int PINK = Color.rgb(235,45,209);

    LightSyncView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        setFocusable(true);
    }

    static class Step {
        long atMs;
        int color;
        String label;
        Step(long atMs, int color, String label) {
            this.atMs = atMs; this.color = color; this.label = label;
        }
    }

    static class Sector {
        String name;
        int color;
        Sector(String n, int c) { name=n; color=c; }
    }

    static class Project {
        String id, title, venue, date;
        long durationMs;
        ArrayList<Sector> sectors = new ArrayList<>();
        ArrayList<Step> timeline = new ArrayList<>();

        static Project demo() {
            Project x = new Project();
            x.id="skz-br-demo-001";
            x.title="STRAY KIDS — BRASIL 🇧🇷";
            x.venue="Estádio Nacional — Brasília";
            x.date="Data a confirmar";
            x.durationMs=60_000L;
            x.sectors.add(new Sector("Pista", Color.rgb(239,23,64)));
            x.sectors.add(new Sector("Arquibancada A", Color.rgb(255,210,28)));
            x.sectors.add(new Sector("Arquibancada B", Color.rgb(50,217,107)));
            x.sectors.add(new Sector("Cadeira", Color.rgb(35,155,255)));
            x.timeline.add(new Step(0, Color.rgb(35,155,255), "Azul"));
            x.timeline.add(new Step(10_000, Color.rgb(239,23,64), "Vermelho"));
            x.timeline.add(new Step(20_000, Color.WHITE, "Branco"));
            x.timeline.add(new Step(30_000, Color.rgb(255,210,28), "Amarelo"));
            x.timeline.add(new Step(40_000, Color.rgb(50,217,107), "Verde"));
            x.timeline.add(new Step(50_000, Color.rgb(155,57,255), "Roxo"));
            return x;
        }
    }

    void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        p.setTextSize(size);
        p.setColor(color);
        p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(s,x,y,p);
    }

    void card(Canvas c,float l,float t,float r,float b) {
        p.setColor(CARD); p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(l,t,r,b,18,18,p);
    }

    void button(Canvas c,String s,float l,float t,float r,float b) {
        LinearGradient g = new LinearGradient(l,t,r,b,BLUE,PINK,Shader.TileMode.CLAMP);
        p.setShader(g); c.drawRoundRect(l,t,r,b,28,28,p); p.setShader(null);
        p.setTextAlign(Paint.Align.CENTER);
        txt(c,s,(l+r)/2,t+(b-t)/2+5,15,WHITE,true);
        p.setTextAlign(Paint.Align.LEFT);
    }

    void header(Canvas c,String title,boolean back) {
        if(back) txt(c,"‹",18,43,42,WHITE,false);
        txt(c,title,back?58:22,37,22,WHITE,true);
        txt(c,"SKZ LightSync • V0.2",22,getHeight()-16,11,MUTED,false);
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(BG);
        if(screen==0) home(c);
        else if(screen==1) event(c);
        else if(screen==2) sector(c);
        else if(screen==3) download(c);
        else execute(c);
    }

    void home(Canvas c) {
        header(c,"SKZ LightSync",false);
        card(c,18,70,getWidth()-18,310);
        txt(c,"STRAY KIDS FAN PROJECT • BRASIL 🇧🇷",34,105,11,BLUE,true);
        txt(c,"Uma só luz,",34,150,29,WHITE,true);
        txt(c,"o mesmo sonho.",34,184,29,WHITE,true);
        txt(c,"V0.2 • projeto local + execução sincronizada",34,215,13,MUTED,false);
        button(c,"⚡ Abrir projeto",34,245,getWidth()-34,295);

        card(c,18,330,getWidth()-18,430);
        txt(c,project.title,34,362,16,WHITE,true);
        txt(c,project.venue,34,388,12,MUTED,false);
        txt(c,"✓ Projeto disponível offline",34,410,12,Color.rgb(80,220,140),true);
    }

    void event(Canvas c) {
        header(c,"Evento",true);
        card(c,18,70,getWidth()-18,270);
        txt(c,"FAN PROJECT — BRASIL 🇧🇷",34,105,11,BLUE,true);
        txt(c,project.title,34,150,25,WHITE,true);
        txt(c,project.venue,34,185,13,MUTED,false);
        txt(c,project.date,34,208,13,MUTED,false);
        txt(c,"Projeto: "+project.id,34,238,11,MUTED,false);
        button(c,"Escolher meu setor",34,300,getWidth()-34,350);
    }

    void sector(Canvas c) {
        header(c,"Meu setor",true);
        for(int i=0;i<project.sectors.size();i++){
            float y=75+i*82;
            card(c,18,y,getWidth()-18,y+66);
            Sector s=project.sectors.get(i);
            p.setColor(s.color); c.drawCircle(43,y+33,10,p);
            txt(c,s.name,66,y+29,16,WHITE,true);
            txt(c,"Cor base do setor",66,y+50,12,MUTED,false);
            if(selectedSector==i){
                stroke.setColor(WHITE); stroke.setStrokeWidth(2);
                c.drawRoundRect(18,y,getWidth()-18,y+66,18,18,stroke);
            }
        }
        button(c,"Continuar",34,425,getWidth()-34,475);
    }

    void download(Canvas c) {
        header(c,"Projeto pronto",true);
        card(c,18,75,getWidth()-18,285);
        txt(c,"✓ Projeto baixado",34,112,20,Color.rgb(80,220,140),true);
        txt(c,"As etapas estão salvas no aparelho.",34,148,13,MUTED,false);
        txt(c,"Internet: não necessária durante",34,180,13,MUTED,false);
        txt(c,"a execução do projeto.",34,202,13,MUTED,false);
        txt(c,"Sincronização: relógio local",34,238,13,MUTED,false);
        button(c,"Iniciar teste",34,320,getWidth()-34,370);
    }

    int currentStep(long elapsed) {
        int idx=0;
        for(int i=0;i<project.timeline.size();i++){
            if(elapsed >= project.timeline.get(i).atMs) idx=i;
        }
        return idx;
    }

    void execute(Canvas c) {
        if(localStartElapsed==0) localStartElapsed=SystemClock.elapsedRealtime();
        long elapsed=(SystemClock.elapsedRealtime()-localStartElapsed)+clockOffsetMs;
        int idx=currentStep(elapsed);
        Step s=project.timeline.get(idx);

        p.setColor(s.color);
        c.drawRect(0,60,getWidth(),getHeight()-55,p);

        p.setTextAlign(Paint.Align.CENTER);
        int textColor=(s.color==Color.WHITE?Color.BLACK:WHITE);
        txt(c,s.label.toUpperCase(),getWidth()/2,250,32,textColor,true);

        long remain=project.durationMs-elapsed;
        if(remain<0) remain=0;
        txt(c,String.format("%02d:%02d",remain/60000,(remain/1000)%60),getWidth()/2,290,18,textColor,true);
        txt(c,"SETOR: "+project.sectors.get(selectedSector).name,getWidth()/2,320,13,textColor,false);
        txt(c,"SINCRONIZADO • OFFLINE",getWidth()/2,350,12,textColor,true);
        p.setTextAlign(Paint.Align.LEFT);

        if(elapsed >= project.durationMs) localStartElapsed=SystemClock.elapsedRealtime();
        handler.postDelayed(()->invalidate(),100);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float y=e.getY();

        if(screen==0 && y>230 && y<320) screen=1;
        else if(screen==1 && y>285 && y<380) screen=2;
        else if(screen==2) {
            if(y>=70 && y<405) {
                int i=(int)((y-75)/82);
                if(i>=0 && i<project.sectors.size()) selectedSector=i;
            } else if(y>405) screen=3;
        } else if(screen==3 && y>300 && y<400) {
            localStartElapsed=SystemClock.elapsedRealtime();
            screen=4;
        } else if(screen>0 && y<60) screen=Math.max(0,screen-1);

        invalidate();
        return true;
    }
}
