# SKZ LightSync V0.2

Esta versão acrescenta uma arquitetura inicial para execução de fanprojects sem internet.

## O que já está implementado
- Projeto local com ID e metadados.
- Setores e cores.
- Timeline em milissegundos.
- Download representado pelo armazenamento local do projeto.
- Execução offline.
- Relógio de execução baseado no monotonic clock do Android.
- Mudanças automáticas de cor a cada etapa.
- Tela de execução em modo imersivo.

## O que ainda falta para sincronização entre aparelhos
Esta versão ainda usa o relógio local de cada aparelho. Para uso real em estádio, a próxima camada deve:
1. Obter um horário de referência de servidor antes do show.
2. Calcular o offset entre o relógio do aparelho e o horário de referência.
3. Salvar esse offset para uso offline.
4. Definir uma janela de início do projeto.
5. Testar diferenças de relógio e retomada após o app ficar em segundo plano.

Depois disso entra o backend para publicação de projetos e o painel administrativo.
